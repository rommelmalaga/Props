import React from 'react';
import ChildComponent from './ChildComponent';
import DataComponent from './DataComponent';
import GroceryList from './GroceryList';

function ParentComponent(){
    const dynamicValue = "This is a dynamic value."
    const dataVal = "This is a data value."
    
    let groceryList = ["Home","About", "Contact"]
    return(
        <div>
            <ChildComponent 
            subjectNameHandler={dynamicValue}/>
            <DataComponent 
            datavalue={dataVal}/>
            <GroceryList groceryListData ={groceryList} />
        </div>

    )
}

export default ParentComponent;