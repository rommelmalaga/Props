import React from 'react';
import Proptypes from 'prop-types';
import '../App.css'
function GroceryList(props){
    return(
        <ol className='navbar'>
            {
            props.groceryListData.map((itemVal, index)=>
                <li key={index}>{itemVal}</li>
            )
            }
        </ol>

    )
}

GroceryList.Proptypes ={
    groceryListData: Proptypes.string.isRequired
}
export default GroceryList;