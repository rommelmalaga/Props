import React from 'react';

function DataComponent(props){
    return(
        <div>
            {props.datavalue}
        </div>

    )
}

export default DataComponent;