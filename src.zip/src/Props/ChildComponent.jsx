import React from 'react';

function ChildComponent(props){
    return(
        <div>
            {props.subjectNameHandler}
        </div>

    )
}

export default ChildComponent;