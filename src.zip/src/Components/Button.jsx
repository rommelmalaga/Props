import '../App.css';

function Button() {
    return (
        <div className='btn'>
            <h2>This is my content</h2>
        </div>
        
        
    )
}

export default Button;