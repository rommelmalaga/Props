import '../App.css';
import Button from './Button';

function Nav() {
    
    return (
        <div className='nav'>
            <h3>Right SideBar</h3>
        </div>
    )
}
export default Nav;